export default function Container() {
  return (
    <div>
      <h1>Utiliser Tailwind</h1>
    </div>
  )
}
