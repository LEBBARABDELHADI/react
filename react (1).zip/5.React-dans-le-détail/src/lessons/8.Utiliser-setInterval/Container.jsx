export default function Container() {
  
  return (
    <div>
      <h1>Valeur du compteur : </h1>
    </div>
  )
}
