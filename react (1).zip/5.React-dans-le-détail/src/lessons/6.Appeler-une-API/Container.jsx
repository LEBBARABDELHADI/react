import "./Container.css"

export default function Container() {


  return (
    <div>
      <h1>Appeler une API</h1>
     
    </div>
  )
}
