
export default function Container() {

  return (
    <div>
      <h1>Ajouter un évènement global</h1>

    </div>
  )
}
