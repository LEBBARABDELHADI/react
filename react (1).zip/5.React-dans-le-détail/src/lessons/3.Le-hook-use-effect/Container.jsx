import "./Container.css"

export default function Container() {

  
  return (
    <div>
      <h1>Le hook useEffect</h1>
    </div>
  )
}
