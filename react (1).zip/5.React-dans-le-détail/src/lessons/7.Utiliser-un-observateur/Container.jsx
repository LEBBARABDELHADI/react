import "./Container.css";

export default function Container() {

  return (
    <div className="container">
      <h1>Utiliser un observateur</h1>

    </div>
  );
}

