import "./Container.css"

export default function Container() {

  return (
    <div>
      <h1>useMemo</h1>

    </div>
  )
}
