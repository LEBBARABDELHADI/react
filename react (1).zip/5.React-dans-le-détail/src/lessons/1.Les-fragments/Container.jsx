export default function Container() {
  return (
    <div>
      <h1>Les fragments</h1>
    </div>
  )
}
