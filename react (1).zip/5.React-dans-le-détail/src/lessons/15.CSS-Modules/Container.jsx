export default function Container() {

  return (
    <div>
      <h1>CSS Modules</h1>
    </div>
  )
}
