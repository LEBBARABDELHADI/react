export default function Container() {

  return (
    <div>
      <h1>Photo de chats 🐾</h1>

    </div>
  )
}
