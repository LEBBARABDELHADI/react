
export default function Container() {
  return (
    <div>
      <h1>Props children</h1>

    </div>
  )
}
