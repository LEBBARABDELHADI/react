const tabsData = [
  {
    txt: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius quam adipisci saepe sit reiciendis sint voluptatibus fuga officiis quod eaque.",
  },
  {
    txt: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Optio provident voluptatem ipsam exercitationem doloribus! Totam ab nihil ipsum voluptas aperiam beatae expedita quae facilis ducimus. Asperiores officia, suscipit accusantium nisi nam modi, rerum nostrum esse enim earum dolor architecto quos?",
  },
  {
    txt: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi illo a quibusdam voluptatem praesentium repellendus ab reiciendis iusto! Quod hic aliquam, voluptates expedita iure eius corrupti incidunt quos unde doloremque earum, eligendi sequi, nam praesentium. Eius voluptates ullam est omnis similique tempora enim. Aut necessitatibus nesciunt et voluptatibus excepturi. Magni totam modi, similique atque recusandae blanditiis ut necessitatibus explicabo qui?",
  },
]